N = int(input())
if N <= 100:
    print("YES")
else:
    print("NO")