# Quick Start with docker
docker build -t kumano-draft .
docker run -p 5000:5000 kumano-draft
<!-- Boa noite -->

# これは熊野寮の部屋決め会議で用いるwebアプリです。