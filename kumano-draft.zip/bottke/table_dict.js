const tableDict = {};
tableDict[block][i] = 0;

